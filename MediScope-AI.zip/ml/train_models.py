"""Training entry point template.

Each disease requires a separately documented dataset and a pipeline that is
fit only on the training split. Extend the module-specific builders after the
dataset files identified in docs/DATASET_DOCUMENTATION.md are obtained.
"""
from pathlib import Path
import joblib
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

ARTIFACTS = Path(__file__).parent / "artifacts"

def train_diabetes(frame):
    """Example contract: frame contains documented diabetes features and target."""
    features = ["age", "bmi", "glucose", "hba1c"]
    X_train, X_test, y_train, y_test = train_test_split(frame[features], frame["target"], test_size=.2, stratify=frame["target"], random_state=42)
    pipeline = Pipeline([("scale", StandardScaler()), ("classifier", LogisticRegression(max_iter=2000, class_weight="balanced"))])
    pipeline.fit(X_train, y_train)
    print(classification_report(y_test, pipeline.predict(X_test)))
    ARTIFACTS.mkdir(exist_ok=True)
    joblib.dump(pipeline, ARTIFACTS / "diabetes.joblib")
