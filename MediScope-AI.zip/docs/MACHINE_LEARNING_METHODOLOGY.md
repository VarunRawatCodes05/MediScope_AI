# Machine learning methodology

For every module, inspect duplicate rows, missingness and class balance before splitting. Use a stratified held-out test set, fit preprocessing only on training data through a scikit-learn `Pipeline`, compare sensible baselines, then record precision, recall, F1, ROC-AUC, confusion matrix and calibration. Save the selected pipeline and metadata together.
