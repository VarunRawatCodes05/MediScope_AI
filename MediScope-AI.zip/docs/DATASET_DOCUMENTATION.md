# Dataset documentation

Training data must be retrieved by the student and retained with its source and usage terms. Proposed documented public sources are UCI's Pima Indians Diabetes Database, UCI Heart Disease, and UCI Chronic Kidney Disease dataset. Feature schemas must match the selected dataset; missing clinical values are never invented.

Small and historically collected datasets can be biased, incomplete, or non-representative. Held-out metrics and calibration checks must be generated locally before any performance claim is made.
