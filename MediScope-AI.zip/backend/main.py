"""Local FastAPI service for MediScope AI.

Model files are intentionally loaded only after `python ml/train_models.py` has
created them from the documented source datasets.  No clinical output is made
when a model artifact is absent.
"""
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal
import joblib
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent.parent
ARTIFACTS = ROOT / "ml" / "artifacts"
app = FastAPI(title="MediScope AI API", version="0.1.0")

class DiabetesInput(BaseModel):
    age: int = Field(ge=18, le=120)
    bmi: float = Field(ge=10, le=80)
    glucose: float = Field(ge=20, le=700)
    hba1c: float = Field(ge=2, le=20)
    activity: Literal["Low", "Moderate", "High"]

def infer(module: str, payload: dict):
    path = ARTIFACTS / f"{module}.joblib"
    if not path.exists():
        raise HTTPException(503, "Model artifact unavailable. Train the documented local pipeline first.")
    model = joblib.load(path)
    score = float(model.predict_proba([payload])[0][1])
    return {"assessment_status":"complete", "model_score":score,
            "model_version": "local-artifact", "generated_at":datetime.now(timezone.utc).isoformat(),
            "limitations":["Educational screening prototype; not a medical diagnosis."],
            "recommended_next_step":"Discuss concerning results with a qualified healthcare professional."}

@app.get("/api/health")
def health(): return {"status":"ok", "mode":"local", "models_directory":str(ARTIFACTS)}

@app.get("/api/models")
def models():
    return [{"id":n, "artifact_available":(ARTIFACTS / f"{n}.joblib").exists()} for n in ("diabetes","cardiovascular","kidney")]

@app.post("/api/assessments/diabetes")
def diabetes(payload: DiabetesInput): return infer("diabetes", payload.model_dump())
