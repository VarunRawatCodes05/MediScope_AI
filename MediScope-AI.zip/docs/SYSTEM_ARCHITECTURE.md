# System architecture

```mermaid
flowchart LR
  U[Manual input / fictional demos] --> F[React validation & workflow]
  F --> A[FastAPI typed endpoints]
  A --> M[scikit-learn model pipelines]
  A --> D[(SQLite local records)]
  M --> R[Explained research result]
```

No physical device, cloud model, hospital connection, or third-party health API is used.
