# Presentation guide

1. Start the frontend in local mode.
2. Open **New assessment** and select a disease module.
3. Load a fictional demo profile and inspect the fields.
4. Explain that clinical values are manually entered and the result is not a diagnosis.
5. Open **Model information** to discuss dataset provenance and limitations.
6. Use **Assessment history** to show locally stored demonstration records.
