# Limitations and ethics

MediScope AI does not diagnose, measure vital signs, prescribe medication or provide urgent-care advice. Dataset labels, population bias, missing input values and model calibration limit the meaning of any output. Low scores do not provide reassurance, and concerning symptoms should be assessed by a qualified professional.
