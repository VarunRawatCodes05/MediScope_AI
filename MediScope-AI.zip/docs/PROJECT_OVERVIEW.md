# MediScope AI

MediScope AI is an educational, local-first research prototype that structures manually entered health information and sends it to disease-specific machine-learning pipelines. It is not a diagnostic system and must not be used for emergencies or clinical decision making.

The current UI includes an overview, conditional assessment form, local demonstration profiles, history, model transparency view, and print-oriented report workflow foundation.
