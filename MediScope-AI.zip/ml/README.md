# Local ML pipeline

MediScope AI keeps model training separate from application routing. Download datasets only from their documented sources, place them in `ml/data/`, then run the training scripts in a Python environment with `backend/requirements.txt` installed.

Artifacts are excluded from Git and must be generated locally. The API refuses prediction requests when an artifact is missing instead of manufacturing a result.
