# Testing

Frontend: `npm run build` verifies TypeScript and production bundling. Add Vitest component tests for form validation and assessment flows.

Backend: after Python is installed, run `python -m pytest` in `backend/`. Tests must include invalid input, missing artifact behavior, model loading and feature-schema tests.
